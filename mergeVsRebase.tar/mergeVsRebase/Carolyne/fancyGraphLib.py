def silverBullet(anyProblem):
   return 42
